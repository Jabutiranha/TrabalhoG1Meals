export const MEALS_API_BASE_URL = "https://www.themealdb.com/api.php"
export const MEALS_API_KEY = "1"

export const GET_CATEGORY_MEALS = "www.themealdb.com/api/json/v1/1/categories.php"



