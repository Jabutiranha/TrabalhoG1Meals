import { Text, View } from "react-native"

const Meals = () => {
    return (
        <View>
            <Text>Refeições
            </Text>
        </View>
    )
}

export default Meals