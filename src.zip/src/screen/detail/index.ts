import DetailsMeals from "./DetailsMeals"
export {
    DetailsMeals,
    
}