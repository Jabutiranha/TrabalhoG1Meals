import { Text, View } from "react-native"

const DetailsMeals = () => {
    return (
        <View>
            <Text>Detalhes refeições</Text>
        </View>
    )
}

export default DetailsMeals