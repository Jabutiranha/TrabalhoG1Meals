import { Text, View } from "react-native"

const CategoryMeals = () => {
    return (
        <View>
            <Text>Categorias</Text>
        </View>
    )
}

export default CategoryMeals