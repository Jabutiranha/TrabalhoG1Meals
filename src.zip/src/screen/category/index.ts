import CategoryMeals from "./CategoryMeals";

export {
    CategoryMeals,
    
}