import * as MealsService from './MealsService'

export {
    MealsService,
}
