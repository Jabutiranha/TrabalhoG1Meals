import httpClient from "./HttpClient";

export {
    httpClient,
}
