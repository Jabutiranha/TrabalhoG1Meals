import AppNavigator from "./AppNavigator";
import type { AppNavigatorProps } from "./interface";

export {
    AppNavigator,
    AppNavigatorProps,
}